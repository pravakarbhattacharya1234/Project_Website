// Retrieve the CSV data using a fetch request
fetch('data.csv')
  .then(response => response.text())
  .then(data => {
    // Convert the CSV data to an array of objects
    const dataArray = csvToArray(data);
    // Build the HTML table from the array of objects
    const table = buildTable(dataArray);
    // Add the table to the DOM
    document.getElementById('data-table').appendChild(table);
  })
  .catch(error => console.error(error));

// Function to convert CSV data to an array of objects
function csvToArray(csvData) {
  const lines = csvData.split('\n');
  const headers = lines[0].split(',');
  const data = [];
  for (let i = 1; i < lines.length; i++) {
    const obj = {};
    const line = lines[i].split(',');
    for (let j = 0; j < headers.length; j++) {
      obj[headers[j]] = line[j];
    }
    data.push(obj);
  }
  return data;
}

// Function to build an HTML table from an array of objects
function buildTable(data) {
  const table = document.createElement('table');
  // Build the table header row
  const headerRow = document.createElement('tr');
  for (let key in data[0]) {
    const headerCell = document.createElement('th');
    headerCell.textContent = key;
    headerRow.appendChild(headerCell);
  }
  table.appendChild(headerRow);
  // Build the table data rows
  for (let i = 0; i < data.length; i++) {
    const dataRow = document.createElement('tr');
    for (let key in data[i]) {
      const dataCell = document.createElement('td');
      dataCell.textContent = data[i][key];
      dataRow.appendChild(dataCell);
    }
    table.appendChild(dataRow);
  }
  return table;
}
