// This is an example JavaScript code that you can modify according to your needs.
// For instance, you can use this code to add interactivity to your page.

console.log('Hello World!');
