function submitForm(event) {
    event.preventDefault();
  
    // Retrieve form values
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
  
    // Do something with the form data
    console.log("Username:", username);
    console.log("Email:", email);
    console.log("Password:", password);
    console.log("Category:", category);
    
    Swal.fire({
      icon: "success",
      title: "Registered successfully!",
      showConfirmButton: false,
      timer: 1500
    });
  
    // Optionally, you can redirect the user to another page after the pop-up
    window.location.href = "success.html";
  }
  
  