<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form values
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Validate and process the data
    // You can perform further validation or sanitization of the data here
    // For simplicity, we'll just save the data to a file

    // Create a new user object
    $user = [
        'username' => $username,
        'email' => $email,
        'password' => $password
    ];

    // Save the user data to a file
    $file = 'users.json';

    // Read existing data from the file
    $existingData = file_get_contents($file);
    $users = json_decode($existingData, true) ?? [];

    // Add the new user to the array
    $users[] = $user;

    // Convert the array back to JSON
    $jsonData = json_encode($users);

    // Save the JSON data to the file
    file_put_contents($file, $jsonData);

    // Redirect the user to a success page or perform any other action
    header("Location: success.html");
    exit;
}
?>
